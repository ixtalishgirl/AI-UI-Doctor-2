/* =============================================================================
 * Admin Overlay — Popup Controller
 * Handles all popup-side wiring for the Admin Overlay feature.
 * Loaded at the end of popup.html after popup.js.
 * =========================================================================== */

(function () {
  const $  = (sel) => document.querySelector(sel);
  const setAdminStatus = (el, msg, type) => {
    if (!el) return;
    el.textContent = msg;
    el.className = 'status ' + (type || '');
    if (msg) setTimeout(() => { if (el.textContent === msg) { el.textContent = ''; el.className = 'status'; } }, 4000);
  };

  /* ── helpers ── */
  async function getActiveTabId() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) throw new Error('No active tab found.');
    return tab.id;
  }

  async function sendToContent(msg) {
    const tabId = await getActiveTabId();
    return chrome.tabs.sendMessage(tabId, msg);
  }

  function getOverlayConfig(positionSel, themeSel, modules) {
    return {
      position:  ($(positionSel) || {}).value || 'bottom',
      theme:     ($(themeSel)    || {}).value || 'dark',
      opacity:   ($('#adminOpacity')          || { value: 95 }).value,
      modules: {
        session: modules.session,
        balance: modules.balance,
        headers: modules.headers,
        flags:   modules.flags,
        network: modules.network,
        dom:     modules.dom,
      },
    };
  }

  /* ── Toggle the full Admin Overlay panel (header 👑 button) ── */
  const overlayPanelEl  = $('#adminOverlayPanel');
  const overlayBtnEl    = $('#adminOverlayBtn');
  const overlayCloseBtnEl = $('#adminOverlayClose');
  const quickBtn        = $('#adminOverlayQuickBtn');

  function toggleAdminPanel() {
    if (!overlayPanelEl) return;
    overlayPanelEl.classList.toggle('hidden');
  }

  if (overlayBtnEl)    overlayBtnEl.addEventListener('click', toggleAdminPanel);
  if (overlayCloseBtnEl) overlayCloseBtnEl.addEventListener('click', toggleAdminPanel);
  if (quickBtn)        quickBtn.addEventListener('click', toggleAdminPanel);

  /* ── Quick flag buttons inside full panel ── */
  document.querySelectorAll('.admin-flag-btn').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const field = btn.dataset.field;
      const value = btn.dataset.value;
      const statusEl = $('#adminPanelStatus');
      try {
        await sendToContent({ type: 'ADMIN_INJECT_FLAG', field, value });
        setAdminStatus(statusEl, `✔ ${field} → ${value} injected into window state`, 'ok');
      } catch (err) {
        setAdminStatus(statusEl, `Flag inject failed: ${err.message}`, 'error');
      }
    });
  });

  /* ── Full panel inject button ── */
  const adminInjectBtn = $('#adminInjectBtn');
  if (adminInjectBtn) {
    adminInjectBtn.addEventListener('click', async () => {
      const statusEl = $('#adminPanelStatus');
      try {
        const cfg = getOverlayConfig('#adminPosition', '#adminTheme', {
          session: ($('#modSession') || {}).checked !== false,
          balance: ($('#modBalance') || {}).checked !== false,
          headers: ($('#modHeaders') || {}).checked !== false,
          flags:   ($('#modFlags')   || {}).checked !== false,
          network: ($('#modNetwork') || {}).checked !== false,
          dom:     ($('#modDom')     || {}).checked || false,
        });
        setAdminStatus(statusEl, 'Injecting…');
        await sendToContent({ type: 'ADMIN_OVERLAY_INJECT', config: cfg });
        setAdminStatus(statusEl, '👑 Admin Overlay injected! Look at the page.', 'ok');
      } catch (err) {
        setAdminStatus(statusEl, 'Inject failed: ' + err.message + ' — make sure you are on a real website.', 'error');
      }
    });
  }

  /* ── Full panel remove button ── */
  const adminRemoveBtn = $('#adminRemoveBtn');
  if (adminRemoveBtn) {
    adminRemoveBtn.addEventListener('click', async () => {
      const statusEl = $('#adminPanelStatus');
      try {
        await sendToContent({ type: 'ADMIN_OVERLAY_REMOVE' });
        setAdminStatus(statusEl, '✔ Admin Overlay removed.', 'ok');
      } catch (err) {
        setAdminStatus(statusEl, 'Remove failed: ' + err.message, 'error');
      }
    });
  }

  /* ── Quick inject (Manual Toolbox card) ── */
  const quickInjectBtn  = $('#quickAdminInject');
  const quickRemoveBtn  = $('#quickAdminRemove');
  const quickStatusEl   = $('#quickAdminStatus');

  if (quickInjectBtn) {
    quickInjectBtn.addEventListener('click', async () => {
      try {
        const cfg = getOverlayConfig('#quickAdminPosition', '#quickAdminTheme', {
          session: ($('#qmodSession') || {}).checked !== false,
          balance: ($('#qmodBalance') || {}).checked !== false,
          headers: true,
          flags:   ($('#qmodFlags')   || {}).checked !== false,
          network: ($('#qmodNetwork') || {}).checked || false,
          dom:     ($('#qmodDom')     || {}).checked || false,
        });
        setAdminStatus(quickStatusEl, 'Injecting…');
        await sendToContent({ type: 'ADMIN_OVERLAY_INJECT', config: cfg });
        setAdminStatus(quickStatusEl, '👑 Admin Overlay is now live on the page!', 'ok');
      } catch (err) {
        setAdminStatus(quickStatusEl, 'Inject failed: ' + err.message + ' — navigate to a real website first.', 'error');
      }
    });
  }

  if (quickRemoveBtn) {
    quickRemoveBtn.addEventListener('click', async () => {
      try {
        await sendToContent({ type: 'ADMIN_OVERLAY_REMOVE' });
        setAdminStatus(quickStatusEl, '✔ Overlay removed from page.', 'ok');
      } catch (err) {
        setAdminStatus(quickStatusEl, 'Remove failed: ' + err.message, 'error');
      }
    });
  }
})();
